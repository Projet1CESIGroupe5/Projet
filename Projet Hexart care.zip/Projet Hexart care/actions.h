#ifndef ACTIONS_H_INCLUDED
#define ACTIONS_H_INCLUDED

void afficher_ordre(Valeurs *vlist);
void tri_croissant_temps(Valeurs *vlist);
void tri_decroissant_temps(Valeurs *vlist);
void tri_croissant_poul(Valeurs *vlist);
void tri_decroissant_poul(Valeurs *vlist);
void nb_valeurs(Valeurs *vlist);
void valeurs_mini(Valeurs *vlist);
void afficher(Valeurs* vlist, int size);

#endif // ACTIONS_H_INCLUDED
