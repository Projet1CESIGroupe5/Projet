#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

int main()
{
    menu();
}





